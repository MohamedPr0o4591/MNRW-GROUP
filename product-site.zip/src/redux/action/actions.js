import axios from "axios";
import {
  GET_ALLPRODUCTS,
  GET_CATEGORIES,
  GET_COMPANIES,
  GET_RECENT_ORDER,
  GETTOKENACCESS,
  GETTOKENPROFILEINFO,
} from "../types/allTypes";

export const get_all_categories = (_) => {
  return async (dispatch) => {
    const res = await axios.get(
      `${import.meta.env.VITE_API_HOST}/categories/get_categories.php`
    );

    dispatch({
      type: GET_CATEGORIES,
      payload: res.data.categories,
    });
  };
};

export const get_companies = (_) => {
  return async (dispatch) => {
    const res = await axios.get(
      `${import.meta.env.VITE_API_HOST}/companies/get_companies.php`
    );

    dispatch({
      type: GET_COMPANIES,
      payload: res.data.companies,
    });
  };
};

export const get_pro = (_) => {
  return async (dispatch) => {
    let res = await axios.get(
      `${import.meta.env.VITE_API_HOST}/products/fetch_allPro.php`
    );

    dispatch({
      type: GET_ALLPRODUCTS,
      payload: res.data.products,
    });
  };
};

export const get_recent_order_data = (token) => {
  return async (dispatch) => {
    let res = await axios.get(
      `${import.meta.env.VITE_API_HOST}/profile/latest_orders.php`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );

    dispatch({
      type: GET_RECENT_ORDER,
      payload: res.data.orders,
    });
  };
};

export const get_userdata_token = (token) => {
  return async (dispatch) => {
    let res = await axios.get(
      `${import.meta.env.VITE_API_HOST}/auth/checkAuth.php`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );

    dispatch({
      type: GETTOKENACCESS,
      payload: res.data.user,
    });
  };
};

export const get_profile_info = (token) => {
  return async (dispatch) => {
    let res = await axios.get(
      `${
        import.meta.env.VITE_API_HOST
      }/profile/fitch_profileData.php?u_id=${token}`
    );

    dispatch({
      type: GETTOKENPROFILEINFO,
      payload: res.data.user,
    });
  };
};
