import { Avatar, Box, Container, Stack } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  get_recent_order_data,
  get_userdata_token,
} from "../../../redux/action/actions";
import {
  AutorenewRounded,
  CalendarMonthRounded,
  PersonRounded,
  VerifiedRounded,
} from "@mui/icons-material";
import visaLogo from "../../../assets/Visa-Card-Logo-No-Background.png";
import AddVisaCardComponent from "./visa card/AddVisaCardComponent";

function ModifyProfile(props) {
  const mainInfo = useSelector((state) => state.GET_USERDATA_TOKEN.user);
  const ordersData = useSelector((state) => state.GET_RECENT_ORDERS.orders);
  const dispatch = useDispatch();

  useEffect(() => {
    let token =
      sessionStorage.getItem("token") || localStorage.getItem("token");

    dispatch(get_userdata_token(token));
    dispatch(get_recent_order_data(token));
  }, []);

  const [addVisaOpen, setAddVisaOpen] = useState(false);

  return (
    <Container className="modify-profile">
      <Stack
        direction={"row"}
        alignItems={"center"}
        justifyContent={"space-between"}
      >
        <Avatar
          sx={{ width: 100, height: 100 }}
          src={`${import.meta.env.VITE_API_HOST}/upload/${
            props.userData.img_profile
          }`}
        />

        <Box className="main-info">
          <h2>
            {props.userData.f_name} {props.userData.l_name}
          </h2>

          <p className="username">@{mainInfo.username}</p>
          <span className="email">{mainInfo.email}</span>
        </Box>

        <Box className="info">
          <p>
            <PersonRounded /> {props.userData.gender}
          </p>

          <p>
            <CalendarMonthRounded />{" "}
            {new Date(props.userData.b_day).toLocaleDateString("en-US")}
          </p>
        </Box>
      </Stack>

      <br />
      <hr />
      <br />

      <h3>VISA Info</h3>

      <div className="card-info" id="card">
        <section className="front">
          <div className="header">
            <img src={visaLogo} />

            <p>master card</p>
          </div>

          <div className="card-number">
            {Array.from({ length: 16 }).map((_, index) => {
              return (
                <span key={index} className="number">
                  <span>#</span>
                  {(index + 1) % 4 == 0 && " "}
                </span>
              );
            })}
          </div>

          <Stack
            direction={"row"}
            alignItems={"center"}
            justifyContent={"space-between"}
            className="card-additional-info"
          >
            <div className="left-side">
              <span>card holder</span>
              <p>Name Of Card</p>
            </div>
            <div className="right-side">
              <p>Valid Thru</p>
              <p>MM/YY</p>
            </div>
          </Stack>
        </section>
        <section className="back">
          <div className="header"></div>

          <div className="cvv">
            <p>CVV</p>
            <div className="input-preview">
              <span>***</span>
            </div>
          </div>
        </section>
      </div>

      <br />

      <hr />

      <br />

      <h3>Recent Orders</h3>

      <AddVisaCardComponent setOpen={setAddVisaOpen} open={addVisaOpen} />

      <table className="recent-orders">
        <thead>
          <tr>
            <th>id</th>
            <th>img</th>
            <th>name</th>
            <th>quantity</th>
            <th>status</th>
          </tr>
        </thead>

        <tbody>
          {ordersData?.length > 0
            ? ordersData.map((data, index) => {
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>
                      <img
                        src={`${import.meta.env.VITE_API_HOST}/upload/${
                          data.img
                        }`}
                        alt={data.name}
                      />
                    </td>
                    <td>{data.name}</td>
                    <td>{data.quantity}</td>
                    <td>
                      {data.status == "pending" ? (
                        <span className="pending" style={{ color: "tomato" }}>
                          <AutorenewRounded />
                          الطلب قيد المراجعة
                        </span>
                      ) : (
                        <span className="pending" style={{ color: "green" }}>
                          <VerifiedRounded />
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })
            : null}
        </tbody>
      </table>
    </Container>
  );
}

export default ModifyProfile;
