import * as React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import { Stack } from "@mui/material";
import visaLogo from "../../../../assets/Visa-Card-Logo-No-Background.png";
import "./AddVisaCardComponent.css";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "60%",
  maxHeight: "80vh",
  bgcolor: "transparent",
  border: "none",
  outline: "none",
  boxShadow: 0,
  padding: "40px 70px",
  color: "#000",
  overflow: "auto",
};

function AddVisaCardComponent(props) {
  const handleClose = () => props.setOpen(false);

  return (
    <div className="add-credit-card">
      <Modal
        open={props.open}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <h2>Add / Update Card</h2>

          <div className="container">
            <div className="card-info" id="card">
              <section className="front">
                <div className="header">
                  <img src={visaLogo} />

                  <p>master card</p>
                </div>

                <div className="card-number">
                  {Array.from({ length: 16 }).map((_, index) => {
                    return (
                      <span key={index} className="number">
                        <span>#</span>
                        {(index + 1) % 4 == 0 && " "}
                      </span>
                    );
                  })}
                </div>

                <Stack
                  direction={"row"}
                  alignItems={"center"}
                  justifyContent={"space-between"}
                  className="card-additional-info"
                >
                  <div className="left-side">
                    <span>card holder</span>
                    <p>Name Of Card</p>
                  </div>
                  <div className="right-side">
                    <p>Valid Thru</p>
                    <p>MM/YY</p>
                  </div>
                </Stack>
              </section>
              <section className="back">
                <div className="header"></div>

                <div className="cvv">
                  <p>CVV</p>
                  <div className="input-preview">
                    <span>***</span>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </Box>
      </Modal>
    </div>
  );
}

export default AddVisaCardComponent;
